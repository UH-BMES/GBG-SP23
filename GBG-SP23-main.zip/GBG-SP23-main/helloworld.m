% Please fix the syntax error in this file, then follow the general Git workflow (create branch -> pull -> modify -> commit -> pull request) to update the file
fpirntf("Hello world!");
